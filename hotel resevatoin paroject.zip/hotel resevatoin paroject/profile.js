// Retrieve username from local storage
const storedUsername = localStorage.getItem("username");

// Display username on the profile page
document.getElementById("username").textContent = storedUsername;
