
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="Login.css">
</head>
<body>

  <!--*****to edit background******-->
  <div class="background-container"></div>

  <!--********header part***********-->
  <header>
    <img class="logoimg" src="company logo.png" alt="Company Logo"><!--Adding a logo-->
    <div class="search-copmany">
      <h1 class="company_name">Flamingo.com</h1>
      <div class="search_bar">
        <input type="text" placeholder="Search for products.." class="search_box"><!--creating a search bar-->
        <ul class="user-icon">
          <a href="profile.html"><img src="icon/user icon.png" alt="user-icon"></a><!--change user icon-->
        </ul>
      </div>
    </div>
  </header>
  <!--********End of the header part***********-->


  <!--************Navigation bar************-->
  <div class="main-nav">
    <div class="right-button">
      <a href="Home.html" class="button">Home</a>
      <a href="facilities.html" class="button">Facilities</a>
      <a href="Home.html#gallary" class="button">Gallery</a>
      <a href="Home.html#about_us" class="button">About Us</a>
      <a href="Event.html" class="button">Events</a>
      <a href="Rating.html" class="button">Reviews and Ratings</a>
    </div>
    <div class="spacer">
      <a href="register.html" class="Rbutton">Register</a>
      <a href="Login.html" class="Lbutton">Log in</a>
    </div>
  </div>
  <!--************end of theNavigation bar************-->


  <!--******start of the login page html***-->

  <section id="login" class="">
    <h1>Admin Login In</h1>
    <form>
        <label for="username">User Name</label><br>
        <input type="text" id="username" name="username"><br>
        <label for="password">Password</label><br>
        <input type="password" id="password" name="password"><br>
        <input type="checkbox" id="remember" name="remember">
        <label for="remember">Remember me</label><br>
        <input type="submit" value="Sign In"><br>
    </form>
    <p><a href="forgot_password.html">Forgot password? Click Here</a></p>
    <p>Don't have an account? <a href="register.html">Create an account</a></p>
  </section>

  <!--******end of the login page html***-->


  <!--*****footer part****-->
 <div class="footer_content">
  <footer>
      <p>All rights to Flamingo | <a href="#">Contact us</a> | <a href="#">Help</a></p>
      <div class="icon">
          <a href="https://www.facebook.com"><img src="icon/facebook icon.png" alt="Facebook"></a>
          <a href="https://www.instagram.com"><img src="icon/inster.png" alt="Instagram"></a>
          <a href="https://twitter.com/?lang=en"><img src="icon/Twitter logo .png" alt="tiwtter"></a>
      </div>
  </footer>
</div>
<!--*****end of the footer part****-->

</body>
</html>
